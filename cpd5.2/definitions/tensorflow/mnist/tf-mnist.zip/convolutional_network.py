"""
A Convolutional Network implementation example using TensorFlow library.
This example is using the MNIST database of handwritten digits
(http://yann.lecun.com/exdb/mnist/)

Author: Aymeric Damien
Project: https://github.com/aymericdamien/TensorFlow-Examples/
"""

import tensorflow as tf

tf.compat.v1.disable_eager_execution()
import input_data
import sys
import os
import itertools
import re
import time
from random import randint
import json
from emetrics import EMetrics

train_images_file = ""
train_labels_file = ""
test_images_file = ""
test_labels_file = ""

test_metrics = []
# Parameters
learning_rate = 0.001
training_iters = 5000
batch_size = 128
display_step = 50

data_dir = os.environ["DL_WORK_DIR"]

model_path = os.environ["RESULT_DIR"] + "/model"
tb_directory = os.environ["LOG_DIR"] + "/tb"
tf.io.gfile.makedirs(tb_directory)

# This helps distinguish instances when the training job is restarted.
instance_id = randint(0, 9999)


def main(argv):
    if len(argv) < 12:
        sys.exit("Not enough arguments provided.")

    global train_images_file, train_labels_file, test_images_file, test_labels_file, learning_rate, training_iters

    i = 1
    while i <= 12:
        arg = str(argv[i])
        if arg == "--trainImagesFile":
            train_images_file = str(argv[i + 1])
        elif arg == "--trainLabelsFile":
            train_labels_file = str(argv[i + 1])
        elif arg == "--testImagesFile":
            test_images_file = str(argv[i + 1])
        elif arg == "--testLabelsFile":
            test_labels_file = str(argv[i + 1])
        elif arg == "--learningRate":
            learning_rate = float(argv[i + 1])
        elif arg == "--trainingIters":
            training_iters = int(argv[i + 1])
        i += 2


print(
    train_images_file,
    train_labels_file,
    test_images_file,
    test_labels_file,
    learning_rate,
    training_iters,
)


if __name__ == "__main__":
    main(sys.argv)

print(sys.argv)
# Import MINST data
train_images_file = data_dir + "/" + train_images_file
train_labels_file = data_dir + "/" + train_labels_file
test_images_file = data_dir + "/" + test_images_file
test_labels_file = data_dir + "/" + test_labels_file

mnist = input_data.read_data_sets(
    train_images_file,
    train_labels_file,
    test_images_file,
    test_labels_file,
    one_hot=True,
)

batchs_per_epoch = mnist.train.num_examples / batch_size + 1
print("batchs_per_epoch:", batchs_per_epoch)
try:
    hyper_params = json.loads(open("config.json").read())
    print("hyper_params:", hyper_params)
    learning_rate = float(hyper_params.get("learning_rate", "0.01"))
    epochs = int(hyper_params.get("epochs", "10"))
    training_iters = epochs * batchs_per_epoch
except Exception:
    print("failed to get hyper-parameters from config.json")

# Network Parameters
n_input = 784  # MNIST data input (img shape: 28*28)
n_classes = 10  # MNIST total classes (0-9 digits)
dropout = 0.75  # Dropout, probability to keep units

# tf Graph input
x = tf.compat.v1.placeholder(tf.float32, [None, n_input], name="x_input")
y = tf.compat.v1.placeholder(tf.float32, [None, n_classes])


# Create some wrappers for simplicity
def conv2d(x, W, b, strides=1):
    # Conv2D wrapper, with bias and relu activation
    x = tf.nn.conv2d(
        input=x, filters=W, strides=[1, strides, strides, 1], padding="SAME"
    )
    x = tf.nn.bias_add(x, b)
    return tf.nn.relu(x)


def maxpool2d(x, k=2):
    # MaxPool2D wrapper
    return tf.nn.max_pool2d(
        input=x, ksize=[1, k, k, 1], strides=[1, k, k, 1], padding="SAME"
    )


# Create model
def conv_net(x, weights, biases, dropout):
    # Reshape input picture
    x = tf.reshape(x, shape=[-1, 28, 28, 1])

    # Convolution Layer
    conv1 = conv2d(x, weights["wc1"], biases["bc1"])
    # Max Pooling (down-sampling)
    conv1 = maxpool2d(conv1, k=2)

    # Convolution Layer
    conv2 = conv2d(conv1, weights["wc2"], biases["bc2"])
    # Max Pooling (down-sampling)
    conv2 = maxpool2d(conv2, k=2)

    # Fully connected layer
    # Reshape conv2 output to fit fully connected layer input
    fc1 = tf.reshape(conv2, [-1, weights["wd1"].get_shape().as_list()[0]])
    fc1 = tf.add(tf.matmul(fc1, weights["wd1"]), biases["bd1"])
    fc1 = tf.nn.relu(fc1)
    # Apply Dropout
    fc1 = tf.nn.dropout(fc1, 1 - (dropout))

    # Output, class prediction
    out = tf.add(tf.matmul(fc1, weights["out"]), biases["out"])
    return out


# Store layers weight & bias
weights = {
    # 5x5 conv, 1 input, 32 outputs
    "wc1": tf.Variable(tf.random.normal([5, 5, 1, 32])),
    # 5x5 conv, 32 inputs, 64 outputs
    "wc2": tf.Variable(tf.random.normal([5, 5, 32, 64])),
    # fully connected, 7*7*64 inputs, 1024 outputs
    "wd1": tf.Variable(tf.random.normal([7 * 7 * 64, 1024])),
    # 1024 inputs, 10 outputs (class prediction)
    "out": tf.Variable(tf.random.normal([1024, n_classes])),
}

biases = {
    "bc1": tf.Variable(tf.random.normal([32])),
    "bc2": tf.Variable(tf.random.normal([64])),
    "bd1": tf.Variable(tf.random.normal([1024])),
    "out": tf.Variable(tf.random.normal([n_classes])),
}

# Construct model
pred = conv_net(x, weights, biases, dropout)

# Define loss and optimizer
cost = tf.reduce_mean(
    input_tensor=tf.nn.softmax_cross_entropy_with_logits(
        logits=pred, labels=tf.stop_gradient(y)
    )
)
optimizer = tf.compat.v1.train.AdamOptimizer(learning_rate=learning_rate).minimize(cost)

predictor = tf.argmax(input=pred, axis=1, name="predictor")

# Evaluate model
correct_pred = tf.equal(tf.argmax(input=pred, axis=1), tf.argmax(input=y, axis=1))
accuracy = tf.reduce_mean(input_tensor=tf.cast(correct_pred, tf.float32))

tf.compat.v1.summary.scalar("accuracy", accuracy)

# Initializing the variables
init = tf.compat.v1.global_variables_initializer()
em = EMetrics.open()

# Launch the graph
with tf.compat.v1.Session() as sess:
    sess.run(init)

    merged = tf.compat.v1.summary.merge_all()
    train_writer = tf.compat.v1.summary.FileWriter(tb_directory + "/train")
    test_writer = tf.compat.v1.summary.FileWriter(tb_directory + "/test")

    step = 1
    # Keep training until reach max iterations
    while step < training_iters:
        batch_x, batch_y = mnist.train.next_batch(batch_size)
        # Run optimization op (backprop)
        sess.run(optimizer, feed_dict={x: batch_x, y: batch_y})
        if step % display_step == 0:

            # Calculate batch loss and accuracy
            train_summary, train_acc = sess.run(
                [merged, accuracy], feed_dict={x: batch_x, y: batch_y}
            )
            test_summary, test_acc, test_loss = sess.run(
                [merged, accuracy, cost],
                feed_dict={x: mnist.test.images, y: mnist.test.labels},
            )

            train_writer.add_summary(train_summary, step * batch_size)
            test_writer.add_summary(test_summary, step * batch_size)
            em.record(EMetrics.TEST_GROUP, step * batch_size, {"accuracy": test_acc})
            test_metrics.append((step, {"loss": float(test_loss)}))
            # test_metrics.append((step, {"accuracy": float(test_acc)}))
            print(
                "Time "
                + "{:.4f}".format(time.time())
                + ", instance "
                + str(instance_id)
                + ", Iter "
                + str(step)
                + ", Training Accuracy= "
                + "{:.5f}".format(train_acc)
            )
            sys.stdout.flush()
        step += 1
    print("Optimization Finished!")

    # HPO - start
    training_out = []

    for test_metric in test_metrics:
        out = {"steps": test_metric[0]}
        for metric, value in test_metric[1].items():
            out[metric] = value
        training_out.append(out)

    with open("{}/val_dict_list.json".format(os.environ["RESULT_DIR"]), "w") as f:
        json.dump(training_out, f)
        # HPO - end

    classification_inputs = tf.compat.v1.saved_model.utils.build_tensor_info(x)
    classification_outputs_classes = tf.compat.v1.saved_model.utils.build_tensor_info(
        predictor
    )

    classification_signature = (
        tf.compat.v1.saved_model.signature_def_utils.build_signature_def(
            inputs={tf.saved_model.CLASSIFY_INPUTS: classification_inputs},
            outputs={
                tf.saved_model.CLASSIFY_OUTPUT_CLASSES: classification_outputs_classes
            },
            method_name=tf.saved_model.CLASSIFY_METHOD_NAME,
        )
    )

    print("classification_signature content:")
    print(classification_signature)

    # Calculate accuracy for 256 mnist test images
    print(
        "Testing Accuracy:",
        sess.run(
            accuracy, feed_dict={x: mnist.test.images[:256], y: mnist.test.labels[:256]}
        ),
    )

    builder = tf.compat.v1.saved_model.builder.SavedModelBuilder(model_path)
    legacy_init_op = tf.group(tf.compat.v1.tables_initializer(), name="legacy_init_op")
    builder.add_meta_graph_and_variables(
        sess,
        [tf.saved_model.SERVING],
        signature_def_map={
            "predict_images": classification_signature,
        },
        legacy_init_op=legacy_init_op,
    )

    save_path = str(builder.save())
